gcc *.c utils/*.c packet/*.c events/*.c enet/*.c tlse/tlse.c -lpthread -o proxy
